package com.example.laboratorio02

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import org.w3c.dom.Text


private lateinit var actionSentButton: Button
private lateinit var WeightEditText: EditText
private lateinit var HeightEditText: EditText
private lateinit var dataText: TextView
private lateinit var dataResult: TextView
private lateinit var infoText: TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        binding()
        click()

    }

    private fun binding(){
        actionSentButton = findViewById(R.id.button_calculate)
        WeightEditText = findViewById(R.id.PesoEdit)
        HeightEditText = findViewById(R.id.AlturaEdit)
        dataText = findViewById(R.id.REsultado1)
        dataResult = findViewById(R.id.Resultado2)
        infoText = findViewById(R.id.Resultado3)
    }
    private fun calculate(weight : Float, height: Float):Float{
        return weight/(height* height)

    }
    private fun click(){
        actionSentButton.setOnClickListener {
            val weight = WeightEditText.text.toString()
            val  height = HeightEditText.text.toString()

            val result = calculate(weight.toFloat(), height.toFloat())

            if (result<18.5){
                val result1 = "Underweight"
                dataText.text = result1
            }
            if (result > 18.5 && result< 24.99){
                val  result2 = "Healthy"
                dataText.text = result2
            }
            if (result > 25 && result< 29.9){
                val result3 = "Overweight"
                dataText.text = result3
            }
            if (result > 30){
                val result4 = "Obese"
                dataText.text = result4
            }
        }
    }
}
